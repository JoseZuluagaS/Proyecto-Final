
'use strict'

import React from 'react'
import {StyleSheet, Text, View, Component} from 'react-native'

class MapsView extends Component{
  render(){
    return(
      <View>
        <Text>Aca va el mapa</Text>
      </View>
    );
  }
}
